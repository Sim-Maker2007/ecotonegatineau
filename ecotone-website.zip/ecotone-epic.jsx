import React, { useState, useMemo, useEffect } from 'react';

// Ecotone Logo with Antlers SVG
const EcotoneLogo = ({ variant = 'light', size = 'normal' }) => {
  const scale = size === 'small' ? 0.6 : size === 'large' ? 1.4 : 1;
  const fill = variant === 'light' ? '#ffffff' : '#1a1a1a';

  return (
    <svg width={160 * scale} height={60 * scale} viewBox="0 0 160 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Antlers */}
      <g fill={fill}>
        {/* Left Antler */}
        <path d="M45 25 Q40 20 35 10 Q33 5 30 2 M35 10 Q32 12 28 8 M40 18 Q36 16 32 12"
              stroke={fill} strokeWidth="2.5" fill="none" strokeLinecap="round"/>
        {/* Right Antler */}
        <path d="M115 25 Q120 20 125 10 Q127 5 130 2 M125 10 Q128 12 132 8 M120 18 Q124 16 128 12"
              stroke={fill} strokeWidth="2.5" fill="none" strokeLinecap="round"/>
      </g>
      {/* Center Eye/Leaf Emblem */}
      <ellipse cx="80" cy="28" rx="18" ry="14" stroke={fill} strokeWidth="2.5" fill="none"/>
      <ellipse cx="80" cy="28" rx="8" ry="6" fill={fill}/>
      {/* ECOTONE Text */}
      <text x="80" y="52" fontFamily="'Arial Black', Arial, sans-serif" fontSize="16" fontWeight="900"
            fill={fill} textAnchor="middle" letterSpacing="4">
        ecotone
      </text>
    </svg>
  );
};

// Animated Particles Component
const ParticleField = () => {
  const particles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 20,
    duration: 15 + Math.random() * 20,
    size: 2 + Math.random() * 4
  }));

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {particles.map(p => (
        <div
          key={p.id}
          style={{
            position: 'absolute',
            left: `${p.left}%`,
            bottom: '-10px',
            width: `${p.size}px`,
            height: `${p.size}px`,
            borderRadius: '50%',
            background: 'rgba(139, 195, 74, 0.6)',
            boxShadow: '0 0 10px rgba(139, 195, 74, 0.8)',
            animation: `floatUp ${p.duration}s linear infinite`,
            animationDelay: `${p.delay}s`
          }}
        />
      ))}
      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-100vh) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

// Glowing Card Component
const GlowCard = ({ children, color = '#8BC34A', intensity = 'medium' }) => {
  const [isHovered, setIsHovered] = useState(false);
  const glowIntensity = intensity === 'high' ? 60 : intensity === 'medium' ? 40 : 20;

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        position: 'relative',
        borderRadius: '20px',
        transition: 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        transform: isHovered ? 'translateY(-10px) scale(1.02)' : 'translateY(0) scale(1)',
      }}
    >
      {/* Glow Effect */}
      <div style={{
        position: 'absolute',
        inset: '-2px',
        borderRadius: '22px',
        background: `linear-gradient(135deg, ${color}, #4A7F24, ${color})`,
        opacity: isHovered ? 1 : 0.3,
        filter: `blur(${isHovered ? glowIntensity : 10}px)`,
        transition: 'all 0.4s ease',
        zIndex: -1
      }} />
      {/* Card Content */}
      <div style={{
        background: 'linear-gradient(145deg, rgba(30, 35, 25, 0.95), rgba(20, 25, 18, 0.98))',
        borderRadius: '20px',
        border: `1px solid ${isHovered ? color : 'rgba(139, 195, 74, 0.2)'}`,
        overflow: 'hidden',
        backdropFilter: 'blur(10px)',
        transition: 'all 0.4s ease'
      }}>
        {children}
      </div>
    </div>
  );
};

// Product data
const productsData = [
  { id: 1, name: "Canne à lancer Pro Series", category: "fishing", subcategory: "Cannes", price: 149.99, originalPrice: 189.99, image: "🎣", rating: 4.8, reviews: 124, description: "Fibre de carbone professionnelle", inStock: true, featured: true },
  { id: 2, name: "Moulinet Titanium Elite", category: "fishing", subcategory: "Moulinets", price: 229.99, originalPrice: null, image: "🎣", rating: 4.9, reviews: 89, description: "10 roulements, frein magnétique", inStock: true, featured: true },
  { id: 3, name: "Coffre à pêche XL", category: "fishing", subcategory: "Équipement", price: 49.99, originalPrice: 64.99, image: "🧰", rating: 4.6, reviews: 256, description: "50+ compartiments", inStock: true, featured: false },
  { id: 4, name: "Kit leurres (25 pcs)", category: "fishing", subcategory: "Leurres", price: 34.99, originalPrice: null, image: "🪱", rating: 4.7, reviews: 178, description: "Leurres réalistes toutes conditions", inStock: true, featured: false },
  { id: 5, name: "Cuissardes Néoprène Pro", category: "fishing", subcategory: "Vêtements", price: 179.99, originalPrice: 219.99, image: "👢", rating: 4.5, reviews: 67, description: "Isolées, genoux renforcés", inStock: true, featured: true },
  { id: 6, name: "Lunettes Polarisées HD", category: "fishing", subcategory: "Accessoires", price: 89.99, originalPrice: null, image: "🕶️", rating: 4.8, reviews: 203, description: "Vision sous-marine claire", inStock: true, featured: false },
  { id: 7, name: "Kit Mouche Complet", category: "fishing", subcategory: "Cannes", price: 299.99, originalPrice: 379.99, image: "🎣", rating: 4.7, reviews: 45, description: "Canne, moulinet, mouches inclus", inStock: true, featured: true },
  { id: 8, name: "Siège Kayak Confort", category: "fishing", subcategory: "Accessoires", price: 124.99, originalPrice: null, image: "🪑", rating: 4.4, reviews: 92, description: "Ajustable, longues journées", inStock: false, featured: false },
  { id: 9, name: "Arc Compound Predator", category: "hunting", subcategory: "Arcs", price: 599.99, originalPrice: 749.99, image: "🏹", rating: 4.9, reviews: 156, description: "330 FPS, 50-70 lbs ajustable", inStock: true, featured: true },
  { id: 10, name: "Arbalète Phantom X", category: "hunting", subcategory: "Arbalètes", price: 849.99, originalPrice: null, image: "🏹", rating: 4.8, reviews: 78, description: "400 FPS avec lunette", inStock: true, featured: true },
  { id: 11, name: "Manteau Camo Tactique", category: "hunting", subcategory: "Vêtements", price: 189.99, originalPrice: 229.99, image: "🧥", rating: 4.7, reviews: 312, description: "Imperméable, anti-odeur", inStock: true, featured: true },
  { id: 12, name: "Bottes Isolées -40°C", category: "hunting", subcategory: "Vêtements", price: 219.99, originalPrice: null, image: "🥾", rating: 4.6, reviews: 189, description: "Thinsulate 1000g", inStock: true, featured: false },
  { id: 13, name: "Mirador Deluxe Pro", category: "hunting", subcategory: "Affûts", price: 274.99, originalPrice: 324.99, image: "🌲", rating: 4.5, reviews: 134, description: "Plateforme complète", inStock: true, featured: false },
  { id: 14, name: "Cache Ground Blind", category: "hunting", subcategory: "Affûts", price: 199.99, originalPrice: null, image: "⛺", rating: 4.6, reviews: 87, description: "Hub-style, mailles de tir", inStock: true, featured: false },
  { id: 15, name: "Jumelles 10x42 HD", category: "hunting", subcategory: "Optiques", price: 349.99, originalPrice: 429.99, image: "🔭", rating: 4.8, reviews: 223, description: "Verre ED, prismes corrigés", inStock: true, featured: true },
  { id: 16, name: "Lunette Visée 3-9x40", category: "hunting", subcategory: "Optiques", price: 279.99, originalPrice: null, image: "🎯", rating: 4.7, reviews: 167, description: "Multicouche, réticule BDC", inStock: true, featured: false },
  { id: 17, name: "Caméra Trail 24MP", category: "hunting", subcategory: "Accessoires", price: 149.99, originalPrice: 179.99, image: "📷", rating: 4.5, reviews: 298, description: "Vision nocturne 0.2s", inStock: true, featured: false },
  { id: 18, name: "Set Couteaux Chasseur", category: "hunting", subcategory: "Accessoires", price: 79.99, originalPrice: null, image: "🔪", rating: 4.8, reviews: 445, description: "Acier inox, crochet inclus", inStock: true, featured: false },
];

// Star Rating with glow
const StarRating = ({ rating }) => (
  <div style={{ display: 'flex', gap: '2px' }}>
    {[1, 2, 3, 4, 5].map((star) => (
      <span key={star} style={{
        color: star <= rating ? '#8BC34A' : '#3a3a3a',
        textShadow: star <= rating ? '0 0 10px rgba(139, 195, 74, 0.8)' : 'none',
        fontSize: '14px'
      }}>★</span>
    ))}
  </div>
);

// Header Component
const Header = ({ cartCount, onCartClick, onNavigate, currentPage, searchQuery, setSearchQuery }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      transition: 'all 0.3s ease',
      background: scrolled
        ? 'rgba(10, 15, 8, 0.95)'
        : 'linear-gradient(to bottom, rgba(10, 15, 8, 0.8), transparent)',
      backdropFilter: scrolled ? 'blur(20px)' : 'none',
      borderBottom: scrolled ? '1px solid rgba(139, 195, 74, 0.2)' : 'none'
    }}>
      {/* Top Promo Bar */}
      <div style={{
        background: 'linear-gradient(90deg, #2D5016, #4A7F24, #2D5016)',
        padding: '8px 0',
        textAlign: 'center',
        fontSize: '13px',
        color: '#ffffff',
        fontWeight: '500'
      }}>
        <span style={{ animation: 'pulse 2s ease-in-out infinite' }}>
          🔥 VENTE FLASH: Jusqu'à 40% de rabais | Livraison GRATUITE 99$+ 🔥
        </span>
      </div>

      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '16px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '32px' }}>
          {/* Logo */}
          <div onClick={() => onNavigate('home')} style={{ cursor: 'pointer' }}>
            <EcotoneLogo variant="light" />
          </div>

          {/* Search */}
          <div style={{ flex: 1, maxWidth: '500px' }}>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 50px 14px 20px',
                  borderRadius: '50px',
                  border: '2px solid rgba(139, 195, 74, 0.3)',
                  background: 'rgba(255, 255, 255, 0.05)',
                  color: '#ffffff',
                  fontSize: '14px',
                  transition: 'all 0.3s ease',
                  outline: 'none'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#8BC34A';
                  e.target.style.boxShadow = '0 0 20px rgba(139, 195, 74, 0.3)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'rgba(139, 195, 74, 0.3)';
                  e.target.style.boxShadow = 'none';
                }}
              />
              <span style={{
                position: 'absolute',
                right: '20px',
                top: '50%',
                transform: 'translateY(-50%)',
                fontSize: '18px'
              }}>🔍</span>
            </div>
          </div>

          {/* Nav */}
          <nav style={{ display: 'flex', alignItems: 'center', gap: '32px' }}>
            {[
              { id: 'home', label: 'Accueil' },
              { id: 'shop', label: 'Boutique' },
              { id: 'fishing', label: 'Pêche' },
              { id: 'hunting', label: 'Chasse' }
            ].map(item => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id === 'fishing' || item.id === 'hunting' ? 'shop' : item.id)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: currentPage === item.id ? '#8BC34A' : '#ffffff',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  position: 'relative',
                  padding: '8px 0',
                  transition: 'color 0.3s ease'
                }}
              >
                {item.label}
                <span style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: '2px',
                  background: '#8BC34A',
                  transform: currentPage === item.id ? 'scaleX(1)' : 'scaleX(0)',
                  transition: 'transform 0.3s ease',
                  boxShadow: '0 0 10px #8BC34A'
                }} />
              </button>
            ))}

            {/* Cart */}
            <button
              onClick={onCartClick}
              style={{
                position: 'relative',
                background: 'linear-gradient(135deg, #4A7F24, #8BC34A)',
                border: 'none',
                borderRadius: '50px',
                padding: '12px 24px',
                color: '#ffffff',
                fontWeight: 'bold',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                boxShadow: '0 4px 20px rgba(139, 195, 74, 0.4)',
                transition: 'all 0.3s ease'
              }}
            >
              🛒 Panier
              {cartCount > 0 && (
                <span style={{
                  background: '#ff4444',
                  color: '#fff',
                  borderRadius: '50%',
                  width: '22px',
                  height: '22px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  animation: 'bounce 0.5s ease'
                }}>
                  {cartCount}
                </span>
              )}
            </button>
          </nav>
        </div>
      </div>

      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
        @keyframes bounce { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
      `}</style>
    </header>
  );
};

// Epic Hero Section with Video-style background
const HeroSection = ({ onNavigate }) => {
  return (
    <section style={{
      position: 'relative',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
      background: '#0a0f08'
    }}>
      {/* Animated Gradient Background (simulating video) */}
      <div style={{
        position: 'absolute',
        inset: 0,
        background: `
          radial-gradient(ellipse at 20% 50%, rgba(45, 80, 22, 0.4) 0%, transparent 50%),
          radial-gradient(ellipse at 80% 50%, rgba(74, 127, 36, 0.3) 0%, transparent 50%),
          radial-gradient(ellipse at 50% 100%, rgba(139, 195, 74, 0.2) 0%, transparent 50%),
          linear-gradient(180deg, #0a0f08 0%, #1a2518 50%, #0a0f08 100%)
        `,
        animation: 'heroGradient 10s ease-in-out infinite alternate'
      }} />

      {/* Particle Field */}
      <ParticleField />

      {/* Animated Lines */}
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', opacity: 0.1 }}>
        {[...Array(20)].map((_, i) => (
          <div key={i} style={{
            position: 'absolute',
            left: `${i * 5}%`,
            top: 0,
            bottom: 0,
            width: '1px',
            background: 'linear-gradient(to bottom, transparent, #8BC34A, transparent)',
            animation: `lineMove ${3 + i * 0.5}s ease-in-out infinite alternate`,
            animationDelay: `${i * 0.2}s`
          }} />
        ))}
      </div>

      {/* Content */}
      <div style={{
        position: 'relative',
        maxWidth: '1400px',
        margin: '0 auto',
        padding: '120px 24px 80px',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '60px',
        alignItems: 'center'
      }}>
        {/* Left Content */}
        <div>
          <div style={{
            display: 'inline-block',
            background: 'linear-gradient(90deg, rgba(139, 195, 74, 0.2), transparent)',
            borderLeft: '3px solid #8BC34A',
            padding: '8px 20px',
            marginBottom: '24px',
            animation: 'slideInLeft 0.8s ease-out'
          }}>
            <span style={{ color: '#8BC34A', fontWeight: '600', letterSpacing: '3px', fontSize: '14px' }}>
              GATINEAU • OUTAOUAIS
            </span>
          </div>

          <h1 style={{
            fontSize: '72px',
            fontWeight: '900',
            lineHeight: '1',
            marginBottom: '24px',
            background: 'linear-gradient(135deg, #ffffff 0%, #8BC34A 50%, #ffffff 100%)',
            backgroundSize: '200% auto',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            animation: 'shimmer 3s linear infinite'
          }}>
            L'AVENTURE
            <br />
            <span style={{ fontSize: '80px' }}>COMMENCE ICI</span>
          </h1>

          <p style={{
            fontSize: '20px',
            color: '#a0a0a0',
            lineHeight: '1.7',
            marginBottom: '40px',
            maxWidth: '500px'
          }}>
            Équipement de chasse et pêche haut de gamme.
            Plus de <span style={{ color: '#8BC34A', fontWeight: 'bold' }}>15 ans</span> d'expertise
            au service des passionnés du Québec.
          </p>

          <div style={{ display: 'flex', gap: '20px', marginBottom: '60px' }}>
            <button
              onClick={() => onNavigate('shop')}
              style={{
                background: 'linear-gradient(135deg, #8BC34A, #4A7F24)',
                border: 'none',
                borderRadius: '50px',
                padding: '18px 40px',
                color: '#ffffff',
                fontSize: '16px',
                fontWeight: 'bold',
                cursor: 'pointer',
                boxShadow: '0 10px 40px rgba(139, 195, 74, 0.5)',
                transition: 'all 0.3s ease',
                position: 'relative',
                overflow: 'hidden'
              }}
              onMouseEnter={(e) => {
                e.target.style.transform = 'translateY(-3px)';
                e.target.style.boxShadow = '0 15px 50px rgba(139, 195, 74, 0.7)';
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 10px 40px rgba(139, 195, 74, 0.5)';
              }}
            >
              MAGASINER MAINTENANT →
            </button>

            <button
              style={{
                background: 'transparent',
                border: '2px solid rgba(255,255,255,0.3)',
                borderRadius: '50px',
                padding: '18px 40px',
                color: '#ffffff',
                fontSize: '16px',
                fontWeight: 'bold',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                backdropFilter: 'blur(10px)'
              }}
            >
              ▶ VOIR VIDÉO
            </button>
          </div>

          {/* Stats */}
          <div style={{ display: 'flex', gap: '40px' }}>
            {[
              { value: '40+', label: 'Magasins' },
              { value: '15K+', label: 'Produits' },
              { value: '50K+', label: 'Clients' }
            ].map((stat, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{
                  fontSize: '36px',
                  fontWeight: '900',
                  color: '#8BC34A',
                  textShadow: '0 0 30px rgba(139, 195, 74, 0.5)'
                }}>
                  {stat.value}
                </div>
                <div style={{ color: '#666', fontSize: '14px' }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right - Featured Product Showcase */}
        <div style={{ position: 'relative' }}>
          <div style={{
            position: 'absolute',
            inset: '-50px',
            background: 'radial-gradient(circle, rgba(139, 195, 74, 0.15) 0%, transparent 70%)',
            animation: 'pulse 4s ease-in-out infinite'
          }} />

          <GlowCard intensity="high">
            <div style={{ padding: '40px', textAlign: 'center' }}>
              <div style={{
                fontSize: '120px',
                marginBottom: '20px',
                filter: 'drop-shadow(0 0 30px rgba(139, 195, 74, 0.5))'
              }}>
                🏹
              </div>
              <span style={{
                background: '#ff4444',
                color: '#fff',
                padding: '6px 16px',
                borderRadius: '20px',
                fontSize: '12px',
                fontWeight: 'bold'
              }}>
                -20% CETTE SEMAINE
              </span>
              <h3 style={{ color: '#fff', fontSize: '24px', margin: '16px 0 8px', fontWeight: '700' }}>
                Arc Compound Predator
              </h3>
              <p style={{ color: '#888', marginBottom: '16px' }}>330 FPS • 50-70 lbs</p>
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '12px' }}>
                <span style={{
                  fontSize: '32px',
                  fontWeight: '900',
                  color: '#8BC34A',
                  textShadow: '0 0 20px rgba(139, 195, 74, 0.5)'
                }}>
                  $599.99
                </span>
                <span style={{ color: '#666', textDecoration: 'line-through' }}>$749.99</span>
              </div>
            </div>
          </GlowCard>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div style={{
        position: 'absolute',
        bottom: '40px',
        left: '50%',
        transform: 'translateX(-50%)',
        animation: 'bounce2 2s infinite'
      }}>
        <div style={{
          width: '30px',
          height: '50px',
          border: '2px solid rgba(139, 195, 74, 0.5)',
          borderRadius: '20px',
          display: 'flex',
          justifyContent: 'center',
          paddingTop: '10px'
        }}>
          <div style={{
            width: '4px',
            height: '10px',
            background: '#8BC34A',
            borderRadius: '2px',
            animation: 'scrollDot 2s infinite'
          }} />
        </div>
      </div>

      <style>{`
        @keyframes heroGradient {
          0% { transform: scale(1) rotate(0deg); }
          100% { transform: scale(1.1) rotate(2deg); }
        }
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes lineMove {
          0% { opacity: 0.05; }
          100% { opacity: 0.15; }
        }
        @keyframes bounce2 {
          0%, 100% { transform: translateX(-50%) translateY(0); }
          50% { transform: translateX(-50%) translateY(10px); }
        }
        @keyframes scrollDot {
          0% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(15px); }
        }
      `}</style>
    </section>
  );
};

// Category Section with Glowing Cards
const CategorySection = ({ onNavigate, setActiveCategory }) => {
  const categories = [
    {
      id: 'fishing',
      name: 'PÊCHE',
      icon: '🎣',
      description: 'Cannes, moulinets, leurres & plus',
      color: '#0891b2',
      products: 847
    },
    {
      id: 'hunting',
      name: 'CHASSE',
      icon: '🏹',
      description: 'Arcs, optiques, vêtements & équipement',
      color: '#8BC34A',
      products: 1203
    }
  ];

  return (
    <section style={{
      background: 'linear-gradient(180deg, #0a0f08 0%, #111810 100%)',
      padding: '100px 24px'
    }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '60px' }}>
          <h2 style={{
            fontSize: '48px',
            fontWeight: '900',
            color: '#fff',
            marginBottom: '16px'
          }}>
            EXPLOREZ NOS <span style={{ color: '#8BC34A' }}>CATÉGORIES</span>
          </h2>
          <p style={{ color: '#666', fontSize: '18px' }}>
            L'équipement qu'il vous faut pour dominer la nature
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '32px' }}>
          {categories.map((cat) => (
            <GlowCard key={cat.id} color={cat.color} intensity="high">
              <div
                onClick={() => { setActiveCategory(cat.id); onNavigate('shop'); }}
                style={{
                  padding: '50px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '40px'
                }}
              >
                <div style={{
                  fontSize: '100px',
                  filter: `drop-shadow(0 0 40px ${cat.color})`
                }}>
                  {cat.icon}
                </div>
                <div>
                  <h3 style={{ color: '#fff', fontSize: '36px', fontWeight: '900', marginBottom: '8px' }}>
                    {cat.name}
                  </h3>
                  <p style={{ color: '#888', fontSize: '16px', marginBottom: '16px' }}>
                    {cat.description}
                  </p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <span style={{
                      color: cat.color,
                      fontWeight: 'bold',
                      fontSize: '14px'
                    }}>
                      {cat.products}+ produits
                    </span>
                    <span style={{
                      color: cat.color,
                      fontSize: '20px',
                      transition: 'transform 0.3s ease'
                    }}>→</span>
                  </div>
                </div>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
};

// Product Card with Glow
const ProductCard = ({ product, addToCart }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <GlowCard color="#8BC34A" intensity={isHovered ? 'high' : 'medium'}>
      <div
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        style={{ cursor: 'pointer' }}
      >
        {/* Image Area */}
        <div style={{
          height: '220px',
          background: 'linear-gradient(135deg, #1a1f18 0%, #0d0f0c 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          overflow: 'hidden'
        }}>
          {/* Glow behind product */}
          <div style={{
            position: 'absolute',
            width: '150px',
            height: '150px',
            background: 'radial-gradient(circle, rgba(139, 195, 74, 0.3) 0%, transparent 70%)',
            opacity: isHovered ? 1 : 0,
            transition: 'opacity 0.3s ease'
          }} />

          <span style={{
            fontSize: '80px',
            transition: 'all 0.4s ease',
            transform: isHovered ? 'scale(1.1)' : 'scale(1)',
            filter: isHovered ? 'drop-shadow(0 0 30px rgba(139, 195, 74, 0.5))' : 'none'
          }}>
            {product.image}
          </span>

          {/* Badges */}
          <div style={{ position: 'absolute', top: '16px', left: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {product.originalPrice && (
              <span style={{
                background: 'linear-gradient(135deg, #ff4444, #cc0000)',
                color: '#fff',
                padding: '6px 12px',
                borderRadius: '20px',
                fontSize: '11px',
                fontWeight: 'bold',
                boxShadow: '0 4px 15px rgba(255, 68, 68, 0.4)'
              }}>
                SOLDE
              </span>
            )}
          </div>

          {/* Quick Add */}
          <button
            onClick={(e) => { e.stopPropagation(); addToCart(product); }}
            style={{
              position: 'absolute',
              bottom: isHovered ? '16px' : '-50px',
              left: '50%',
              transform: 'translateX(-50%)',
              background: 'linear-gradient(135deg, #8BC34A, #4A7F24)',
              border: 'none',
              borderRadius: '25px',
              padding: '12px 28px',
              color: '#fff',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 25px rgba(139, 195, 74, 0.5)'
            }}
          >
            + AJOUTER
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '20px' }}>
          <p style={{ color: '#8BC34A', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '8px' }}>
            {product.subcategory}
          </p>
          <h3 style={{ color: '#fff', fontSize: '16px', fontWeight: '700', marginBottom: '8px' }}>
            {product.name}
          </h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <StarRating rating={product.rating} />
            <span style={{ color: '#666', fontSize: '12px' }}>({product.reviews})</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{
              fontSize: '22px',
              fontWeight: '900',
              color: '#8BC34A',
              textShadow: '0 0 15px rgba(139, 195, 74, 0.3)'
            }}>
              ${product.price.toFixed(2)}
            </span>
            {product.originalPrice && (
              <span style={{ color: '#666', textDecoration: 'line-through', fontSize: '14px' }}>
                ${product.originalPrice.toFixed(2)}
              </span>
            )}
          </div>
        </div>
      </div>
    </GlowCard>
  );
};

// Featured Products Section
const FeaturedProducts = ({ products, addToCart, onNavigate }) => {
  const featured = products.filter(p => p.featured).slice(0, 8);

  return (
    <section style={{
      background: '#0a0f08',
      padding: '100px 24px',
      position: 'relative'
    }}>
      {/* Background Glow */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '800px',
        height: '800px',
        background: 'radial-gradient(circle, rgba(139, 195, 74, 0.05) 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />

      <div style={{ maxWidth: '1400px', margin: '0 auto', position: 'relative' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '50px'
        }}>
          <div>
            <h2 style={{ fontSize: '42px', fontWeight: '900', color: '#fff', marginBottom: '8px' }}>
              PRODUITS <span style={{ color: '#8BC34A' }}>VEDETTES</span>
            </h2>
            <p style={{ color: '#666' }}>Les favoris de nos experts</p>
          </div>
          <button
            onClick={() => onNavigate('shop')}
            style={{
              background: 'transparent',
              border: '2px solid #8BC34A',
              borderRadius: '50px',
              padding: '14px 32px',
              color: '#8BC34A',
              fontWeight: 'bold',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.target.style.background = '#8BC34A';
              e.target.style.color = '#000';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'transparent';
              e.target.style.color = '#8BC34A';
            }}
          >
            VOIR TOUT →
          </button>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '24px'
        }}>
          {featured.map(product => (
            <ProductCard key={product.id} product={product} addToCart={addToCart} />
          ))}
        </div>
      </div>
    </section>
  );
};

// Shop Page
const ShopPage = ({ products, addToCart, activeCategory, setActiveCategory, searchQuery }) => {
  const [sortBy, setSortBy] = useState('featured');
  const [priceRange, setPriceRange] = useState('all');

  const filteredProducts = useMemo(() => {
    let filtered = [...products];
    if (activeCategory !== 'all') filtered = filtered.filter(p => p.category === activeCategory);
    if (searchQuery) {
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(Number);
      filtered = filtered.filter(p => p.price >= min && (max ? p.price <= max : true));
    }
    switch (sortBy) {
      case 'price-low': filtered.sort((a, b) => a.price - b.price); break;
      case 'price-high': filtered.sort((a, b) => b.price - a.price); break;
      case 'rating': filtered.sort((a, b) => b.rating - a.rating); break;
      default: filtered.sort((a, b) => b.featured - a.featured);
    }
    return filtered;
  }, [products, activeCategory, searchQuery, priceRange, sortBy]);

  return (
    <section style={{
      background: '#0a0f08',
      minHeight: '100vh',
      paddingTop: '140px',
      paddingBottom: '80px'
    }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 24px' }}>
        {/* Header */}
        <div style={{ marginBottom: '40px' }}>
          <h1 style={{ fontSize: '48px', fontWeight: '900', color: '#fff' }}>
            {activeCategory === 'all' ? 'TOUS LES PRODUITS' :
             activeCategory === 'fishing' ? 'ÉQUIPEMENT DE PÊCHE' : 'ÉQUIPEMENT DE CHASSE'}
          </h1>
          <p style={{ color: '#666' }}>{filteredProducts.length} produits trouvés</p>
        </div>

        <div style={{ display: 'flex', gap: '40px' }}>
          {/* Filters */}
          <div style={{ width: '260px', flexShrink: 0 }}>
            <GlowCard>
              <div style={{ padding: '24px' }}>
                <h3 style={{ color: '#fff', fontSize: '18px', fontWeight: '700', marginBottom: '24px' }}>
                  FILTRES
                </h3>

                {/* Category */}
                <div style={{ marginBottom: '24px' }}>
                  <h4 style={{ color: '#8BC34A', fontSize: '12px', letterSpacing: '2px', marginBottom: '12px' }}>CATÉGORIE</h4>
                  {['all', 'fishing', 'hunting'].map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      style={{
                        display: 'block',
                        width: '100%',
                        textAlign: 'left',
                        background: activeCategory === cat ? 'linear-gradient(90deg, rgba(139,195,74,0.2), transparent)' : 'transparent',
                        border: 'none',
                        borderLeft: activeCategory === cat ? '3px solid #8BC34A' : '3px solid transparent',
                        padding: '10px 16px',
                        color: activeCategory === cat ? '#8BC34A' : '#888',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                    >
                      {cat === 'all' ? 'Tout' : cat === 'fishing' ? 'Pêche' : 'Chasse'}
                    </button>
                  ))}
                </div>

                {/* Price */}
                <div style={{ marginBottom: '24px' }}>
                  <h4 style={{ color: '#8BC34A', fontSize: '12px', letterSpacing: '2px', marginBottom: '12px' }}>PRIX</h4>
                  <select
                    value={priceRange}
                    onChange={(e) => setPriceRange(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#1a1f18',
                      border: '1px solid #333',
                      borderRadius: '8px',
                      color: '#fff'
                    }}
                  >
                    <option value="all">Tous les prix</option>
                    <option value="0-100">Moins de 100$</option>
                    <option value="100-300">100$ - 300$</option>
                    <option value="300-9999">300$+</option>
                  </select>
                </div>
              </div>
            </GlowCard>
          </div>

          {/* Products */}
          <div style={{ flex: 1 }}>
            {/* Sort Bar */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '24px',
              padding: '16px 20px',
              background: 'rgba(255,255,255,0.03)',
              borderRadius: '12px'
            }}>
              <span style={{ color: '#666' }}>Affichage de {filteredProducts.length} résultats</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={{
                  padding: '10px 16px',
                  background: '#1a1f18',
                  border: '1px solid #333',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              >
                <option value="featured">Vedettes</option>
                <option value="price-low">Prix: Bas à élevé</option>
                <option value="price-high">Prix: Élevé à bas</option>
                <option value="rating">Mieux notés</option>
              </select>
            </div>

            {/* Product Grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '24px'
            }}>
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} addToCart={addToCart} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Cart Sidebar
const CartSidebar = ({ cart, isOpen, onClose, updateQuantity, removeFromCart, onCheckout }) => {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 99 ? 0 : 9.99;
  const tax = subtotal * 0.14975;
  const total = subtotal + shipping + tax;

  if (!isOpen) return null;

  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.8)',
        zIndex: 200,
        backdropFilter: 'blur(5px)'
      }} />

      <div style={{
        position: 'fixed',
        right: 0,
        top: 0,
        bottom: 0,
        width: '450px',
        background: 'linear-gradient(180deg, #0d1210 0%, #0a0f08 100%)',
        borderLeft: '1px solid rgba(139,195,74,0.2)',
        zIndex: 201,
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* Header */}
        <div style={{
          padding: '24px',
          borderBottom: '1px solid rgba(139,195,74,0.1)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h2 style={{ color: '#fff', fontSize: '20px', fontWeight: '700' }}>
            VOTRE PANIER <span style={{ color: '#8BC34A' }}>({cart.length})</span>
          </h2>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: '#888', fontSize: '28px', cursor: 'pointer' }}
          >
            ×
          </button>
        </div>

        {/* Items */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
          {cart.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 0', color: '#666' }}>
              <div style={{ fontSize: '60px', marginBottom: '16px', opacity: 0.3 }}>🛒</div>
              Votre panier est vide
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} style={{
                display: 'flex',
                gap: '16px',
                padding: '16px',
                marginBottom: '12px',
                background: 'rgba(255,255,255,0.03)',
                borderRadius: '12px',
                border: '1px solid rgba(139,195,74,0.1)'
              }}>
                <div style={{
                  width: '70px',
                  height: '70px',
                  background: '#1a1f18',
                  borderRadius: '10px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '36px'
                }}>
                  {item.image}
                </div>
                <div style={{ flex: 1 }}>
                  <h4 style={{ color: '#fff', fontSize: '14px', marginBottom: '4px' }}>{item.name}</h4>
                  <p style={{ color: '#8BC34A', fontWeight: 'bold' }}>${item.price.toFixed(2)}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '8px' }}>
                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      style={{ width: '28px', height: '28px', background: '#2a2f28', border: 'none', borderRadius: '6px', color: '#fff', cursor: 'pointer' }}>-</button>
                    <span style={{ color: '#fff', width: '30px', textAlign: 'center' }}>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      style={{ width: '28px', height: '28px', background: '#2a2f28', border: 'none', borderRadius: '6px', color: '#fff', cursor: 'pointer' }}>+</button>
                    <button onClick={() => removeFromCart(item.id)}
                      style={{ marginLeft: 'auto', background: 'none', border: 'none', color: '#ff4444', fontSize: '12px', cursor: 'pointer' }}>Retirer</button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div style={{ padding: '24px', borderTop: '1px solid rgba(139,195,74,0.1)' }}>
            <div style={{ marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px', color: '#888' }}>
                <span>Sous-total</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px', color: '#888' }}>
                <span>Livraison</span>
                <span style={{ color: shipping === 0 ? '#8BC34A' : '#888' }}>
                  {shipping === 0 ? 'GRATUIT' : `$${shipping.toFixed(2)}`}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', color: '#888' }}>
                <span>Taxes</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                paddingTop: '16px',
                borderTop: '1px solid rgba(139,195,74,0.2)'
              }}>
                <span style={{ color: '#fff', fontWeight: 'bold', fontSize: '18px' }}>Total</span>
                <span style={{
                  color: '#8BC34A',
                  fontWeight: '900',
                  fontSize: '24px',
                  textShadow: '0 0 20px rgba(139,195,74,0.5)'
                }}>
                  ${total.toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={onCheckout}
              style={{
                width: '100%',
                padding: '18px',
                background: 'linear-gradient(135deg, #8BC34A, #4A7F24)',
                border: 'none',
                borderRadius: '12px',
                color: '#fff',
                fontWeight: 'bold',
                fontSize: '16px',
                cursor: 'pointer',
                boxShadow: '0 10px 30px rgba(139,195,74,0.4)'
              }}
            >
              PASSER LA COMMANDE →
            </button>
          </div>
        )}
      </div>
    </>
  );
};

// Footer
const Footer = () => (
  <footer style={{
    background: 'linear-gradient(180deg, #0a0f08 0%, #050805 100%)',
    borderTop: '1px solid rgba(139,195,74,0.2)',
    padding: '80px 24px 40px'
  }}>
    <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '60px', marginBottom: '60px' }}>
        <div>
          <EcotoneLogo variant="light" size="small" />
          <p style={{ color: '#666', marginTop: '20px', lineHeight: '1.7', fontSize: '14px' }}>
            Votre destination pour l'équipement de chasse et pêche au Québec depuis 2007.
          </p>
        </div>

        {[
          { title: 'MAGASINER', links: ['Pêche', 'Chasse', 'Vêtements', 'Accessoires', 'Soldes'] },
          { title: 'SUPPORT', links: ['Nous contacter', 'FAQ', 'Livraison', 'Retours', 'Magasins'] },
          { title: 'CONTACT', links: ['819-555-HUNT', 'info@ecotone.ca', 'Gatineau, QC'] }
        ].map((col, i) => (
          <div key={i}>
            <h4 style={{ color: '#8BC34A', fontSize: '12px', letterSpacing: '2px', marginBottom: '20px' }}>{col.title}</h4>
            {col.links.map((link, j) => (
              <p key={j} style={{ color: '#666', marginBottom: '10px', fontSize: '14px', cursor: 'pointer' }}>{link}</p>
            ))}
          </div>
        ))}
      </div>

      <div style={{
        borderTop: '1px solid rgba(139,195,74,0.1)',
        paddingTop: '30px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <p style={{ color: '#444', fontSize: '13px' }}>© 2026 Ecotone Gatineau. Tous droits réservés.</p>
        <div style={{ display: 'flex', gap: '16px' }}>
          {['📘', '📸', '🐦'].map((icon, i) => (
            <span key={i} style={{ fontSize: '20px', opacity: 0.5, cursor: 'pointer' }}>{icon}</span>
          ))}
        </div>
      </div>
    </div>
  </footer>
);

// Main App
export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const updateQuantity = (id, qty) => {
    if (qty <= 0) { setCart(prev => prev.filter(item => item.id !== id)); return; }
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: qty } : item));
  };

  const removeFromCart = (id) => setCart(prev => prev.filter(item => item.id !== id));

  const handleNavigate = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0f08' }}>
      <Header
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onCartClick={() => setCartOpen(true)}
        onNavigate={handleNavigate}
        currentPage={currentPage}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {currentPage === 'home' && (
        <>
          <HeroSection onNavigate={handleNavigate} />
          <CategorySection onNavigate={handleNavigate} setActiveCategory={setActiveCategory} />
          <FeaturedProducts products={productsData} addToCart={addToCart} onNavigate={handleNavigate} />
        </>
      )}

      {currentPage === 'shop' && (
        <ShopPage
          products={productsData}
          addToCart={addToCart}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          searchQuery={searchQuery}
        />
      )}

      <Footer />

      <CartSidebar
        cart={cart}
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
        onCheckout={() => alert('Commande passée! Merci!')}
      />
    </div>
  );
}
